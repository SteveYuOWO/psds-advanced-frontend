# 🍭研究生导师双选系统前端

### 1.Introduction

研究生导师双选系统分为前后端，是在校的课程设计。

前端使用了React.js 进行构建，代码链接[戳我](https://github.com/SteveYuOWO/psds-advanced-frontend)。

后端使用了SpringBoot进行构建，代码链接[戳我](https://github.com/SteveYuOWO/psds-advanced-frontend)

文档还在修改中，之后完成后再进行上传